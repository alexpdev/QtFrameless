from QtFrameless.window import execute, FramelessWindow

__all__ = ["execute", "FramelessWindow"]
